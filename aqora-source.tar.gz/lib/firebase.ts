import { initializeApp, getApps, type FirebaseApp } from 'firebase/app';
import { getAuth, type Auth } from 'firebase/auth';
import { getFirestore, type Firestore } from 'firebase/firestore';
import { getStorage, type FirebaseStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: 'AIzaSyDJDDpkxzTrl9pbzScQy7mRFbO0kWTvhZw',
  authDomain: 'aqora-28595165-beb5f.firebaseapp.com',
  projectId: 'aqora-28595165-beb5f',
  storageBucket: 'aqora-28595165-beb5f.firebasestorage.app',
  messagingSenderId: '168023435195',
  appId: '1:168023435195:web:71362611b25e8219a4869e',
};

const app: FirebaseApp = !getApps().length ? initializeApp(firebaseConfig) : getApps()[0];

export const firebaseApp = app;
export const firebaseAuth: Auth = getAuth(app);
export const firebaseFirestore: Firestore = getFirestore(app);
export const firebaseStorage: FirebaseStorage = getStorage(app);
export const firebaseConfigObj = firebaseConfig;
