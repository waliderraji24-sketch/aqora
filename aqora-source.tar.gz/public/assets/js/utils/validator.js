// Validation utilities placeholder
