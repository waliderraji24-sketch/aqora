// UI utilities placeholder
