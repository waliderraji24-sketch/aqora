// Constants placeholder
