// General helper utilities placeholder
