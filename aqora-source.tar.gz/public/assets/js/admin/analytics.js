// Admin analytics placeholder
