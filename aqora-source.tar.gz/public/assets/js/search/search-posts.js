// Search posts placeholder
