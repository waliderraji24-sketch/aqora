// Sharing helper placeholder
