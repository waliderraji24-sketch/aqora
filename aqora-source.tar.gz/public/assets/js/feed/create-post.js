// Create post helper placeholder
