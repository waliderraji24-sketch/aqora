// Friends list placeholder
