// Reports helper placeholder
