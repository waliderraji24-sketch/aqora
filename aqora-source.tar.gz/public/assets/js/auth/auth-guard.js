// Auth guard helper placeholder
