// Register logic placeholder
