// Reel likes helper placeholder
