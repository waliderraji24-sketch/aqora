// User profile helper placeholder
