// Followers helper placeholder
