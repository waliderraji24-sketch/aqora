// Create story helper placeholder
