// Messages handler placeholder
