// Chats helper placeholder
