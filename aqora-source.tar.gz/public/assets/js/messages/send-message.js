// Send message helper placeholder
